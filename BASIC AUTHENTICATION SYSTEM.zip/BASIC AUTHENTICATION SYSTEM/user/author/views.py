from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django import forms
from django.contrib import messages


def index(request):
    return render(request,'index.html')

def signup(request):
    return render(request,'signup.html')

def login(request):
    return render(request,'login.html')
def userdetail(request):
    return render(request,'userdetial.html',{'user': request.user})


def signuppage(request):
        fname=request.POST['fname']
        lname=request.POST['lname']
        email=request.POST['email'] 
        username=request.POST['username']
        password=request.POST['password']
        cpassword=request.POST['cpassword']
        if User.objects.filter(username=username).exists():
           messages.error(request, "Username already exists. Please choose another one.")
           return render(request, 'signup.html')
        if password==cpassword:
           
            user=User.objects.create(first_name=fname,last_name=lname,email=email,username=username)
            user.set_password(password)  
            user.save()
            
            return render(request,'login.html')
            
def Loginpage(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password']
       
        if not username or not password:
            # Show error message if either username or password is missing
            messages.error(request, 'Both username and password are required.')
            return render(request, 'login.html')
        user=User.objects.filter(username=username,password=password).first()
        if user :
            request.session['username'] = username
            return render(request, 'userdetial.html', {'username': username})
        else:
          messages.error(request, 'Invalid username or password.')
          return render(request, 'login.html')
    
    
def logoutpage(request):
    return render(request,'index.html')


        


