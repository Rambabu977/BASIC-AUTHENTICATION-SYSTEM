from django import forms
from .models import User

class Formpage(forms.ModelForm):
    class Meta:
        model = User
       

        
        
